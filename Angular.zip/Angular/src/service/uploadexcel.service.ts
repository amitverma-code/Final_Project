import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserModel } from 'src/entity/User'

type EntityResponseType = HttpResponse<UserModel[]>;
@Injectable({
  providedIn: 'root'
})
export class UploadexcelService {
  constructor(private http:HttpClient) { }

  getAllUserDetails():Observable<EntityResponseType>{
    return this.http.get<UserModel[]>("http://localhost:9999/students", {observe: 'response'});
}

}