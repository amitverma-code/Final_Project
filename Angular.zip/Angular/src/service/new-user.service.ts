import { Injectable } from '@angular/core';
import { HttpResponse, HttpClient } from '@angular/common/http';
import { UserDatabaseModel } from 'src/entity/UserDatabase';
import { Observable } from 'rxjs';

type EntityResponseType = HttpResponse<UserDatabaseModel[]>;

@Injectable({
  providedIn: 'root'
})
export class NewUserService {

  constructor(private http:HttpClient) { }
  getAllUserDatabase():Observable<EntityResponseType>{
    return this.http.get<UserDatabaseModel[]>("http://localhost:5515/userDatabases", {observe: 'response'});
  }

  saveUserDatabase(userDatabaseModel:UserDatabaseModel){
    return this.http.post<UserDatabaseModel>("http://localhost:5515/userDatabase", userDatabaseModel, {observe: 'response'});
  }

}
