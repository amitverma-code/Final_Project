import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExcelModel } from 'src/entity/ExcelModel';
import { ExcelResponseModel } from 'src/entity/ExcelResponseModel';


type EntityResponseType = HttpResponse<ExcelModel[]>;
type EntityResponseType1 = HttpResponse<ExcelResponseModel>;



@Injectable({
  providedIn: 'root'
})
export class ImportExcelService {

  constructor(private http:HttpClient) { }
  getAllDetails():Observable<EntityResponseType>{
    return this.http.get<ExcelModel[]>("http://localhost:5520/stockData", {observe: 'response'});
}

//---------------------------------------------------------summary------------------------------------------------

getAllDetails1():Observable<EntityResponseType1>{
  return this.http.get<ExcelResponseModel>("http://localhost:5520/summary", {observe: 'response'});
}


//----------------------------------------------------------summary------------------------------------------------------

pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
  const formdata: FormData = new FormData();
  formdata.append('file', file);
  const req = new HttpRequest('POST', "http://localhost:5520/import", formdata,{
    reportProgress: true,
    responseType: 'text'
  }
  );
  return this.http.request(req);
}

}