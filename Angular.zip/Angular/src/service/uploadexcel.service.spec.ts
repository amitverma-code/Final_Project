import { TestBed } from '@angular/core/testing';

import { UploadexcelService } from './uploadexcel.service';

describe('UploadexcelService', () => {
  let service: UploadexcelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UploadexcelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
