export interface ExcelModel{
    id:File;
}