export interface CompanyDetailsModel{
    company_name : string;
	turn_over : string;
    ceo : string;
    board_of_directors : string;
	listed_in_stock_exchanges : string;
    sector : string;
    brief_about_companies : string;
    stock_code_in_each_stock_exchange : string;
}