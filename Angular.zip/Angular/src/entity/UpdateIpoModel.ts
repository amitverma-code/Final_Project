export interface UpdateIpoModel{
    id?:number;
    company_name:string;
    stock_exchange:string;
    price_per_share:number;
    total_number_of_shares:string;
    open_date_time:Date;
    remarks:string
}
