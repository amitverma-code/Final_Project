export interface MailModel{
    email:string;
 }