export interface CodeModel{
   code:string;
}