export interface UserDatabaseModel{


    id : string;
	username : string;
	password :string;
	user_type : string;
	email : string;
	mobile_number : string;
	confirmation : string;
}