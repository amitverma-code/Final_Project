import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { ImportDataComponent } from './import-data/import-data.component';
import { ManageCompanyComponent } from './manage-company/manage-company.component';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { UpdateIPOComponent } from './update-ipo/update-ipo.component';
import { CreateCompanyComponent } from './create-company/create-company.component';
import { RouterModule,Routes } from '@angular/router';

import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import {UserDatabaseService} from 'src/service/user-database.service';
import {CompanyDetailsService} from 'src/service/company-details.service';
import { NewUserComponent } from './new-user/new-user.component';
import { from } from 'rxjs';
import { CreatecompanyComponent } from './createcompany/createcompany.component';
import { UploadexcelService } from 'src/service/uploadexcel.service';
import {ChartsModule} from 'ng2-charts';
import { ImportExcelService } from 'src/service/import-excel.service';
import{ FormsModule } from '@angular/forms';
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { SummaryDataComponent } from './summary-data/summary-data.component';
import { BarchartComponent } from './barchart/barchart.component';
import { BarchartstockComponent } from './barchartstock/barchartstock.component';
import { ManageExchangeService } from 'src/service/manage-exchange.service';
import { NewUserService } from 'src/service/new-user.service';

import { UpdateIpoService } from 'src/service/update-ipo.service';
import { IpoDetailsComponent } from './ipo-details/ipo-details.component';
import { MailVerifyComponent } from './mail-verify/mail-verify.component';
//import { IpoDetalisComponent } from './ipo-details/ipo-details.component';


const routes:Routes=[
  {path:'' , redirectTo:'home', pathMatch:'full'},
  {path:'home' , component:HomeComponent},
  {path:'createCompany' , component:CreateCompanyComponent},
  {path:'manageCompany' , component:ManageCompanyComponent},
  {path:'manageExchange' , component:ManageExchangeComponent},
  {path:'updateIPO' , component:UpdateIPOComponent},
  {path:'importData' , component:ImportDataComponent},
  {path:'admin' , component:AdminComponent},
  {path:'user' , component:UserComponent},
  {path:'compareCompany' , component:CompareCompanyComponent},
  {path:'compareSector' , component:CompareSectorComponent},
  {path: 'app-new-user' , component:NewUserComponent},
  {path:'app-company-update', component:CompanyUpdateComponent},
  {path:'app-summary-data', component:SummaryDataComponent},
  {path:'app-barchart', component:BarchartComponent},
  {path:'app-barchartstock', component:BarchartstockComponent},
  {path:'app-ipo-details', component:IpoDetailsComponent},
  {path:'app-mail-verify', component:MailVerifyComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AdminComponent,
    HomeComponent,
    ImportDataComponent,
    ManageCompanyComponent,
    ManageExchangeComponent,
    UpdateIPOComponent,
    CreateCompanyComponent,
    CompareCompanyComponent,
    CompareSectorComponent,
    NewUserComponent,
    CreatecompanyComponent,
    CompanyUpdateComponent,
    SummaryDataComponent,
    BarchartComponent,
    BarchartstockComponent,
    IpoDetailsComponent,
    MailVerifyComponent,
  //  IpoDetalisComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    FormsModule,
    ChartsModule
  ],
  providers: [UserDatabaseService, CompanyDetailsService,UploadexcelService,ImportExcelService,ManageExchangeService,NewUserService ,UpdateIpoService],
  bootstrap: [AppComponent]
})
export class AppModule { }



