import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarchartstockComponent } from './barchartstock.component';

describe('BarchartstockComponent', () => {
  let component: BarchartstockComponent;
  let fixture: ComponentFixture<BarchartstockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarchartstockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarchartstockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
