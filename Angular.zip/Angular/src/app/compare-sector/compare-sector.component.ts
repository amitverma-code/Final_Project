import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-sector',
  templateUrl: './compare-sector.component.html',
  styleUrls: ['./compare-sector.component.css']
})
export class CompareSectorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
